# 💱 Світ Валют

Сучасна платформа для обміну валют з онлайн-бронюванням курсу, адмін-панеллю та панеллю оператора.

![React](https://img.shields.io/badge/React-18.2-blue)
![FastAPI](https://img.shields.io/badge/FastAPI-0.115-green)
![Tailwind CSS](https://img.shields.io/badge/Tailwind-3.4-cyan)
![Docker](https://img.shields.io/badge/Docker-Ready-blue)

## 📋 Зміст

- [Можливості](#-можливості)
- [Технології](#-технології)
- [Швидкий старт](#-швидкий-старт)
- [Облікові записи](#-облікові-записи)
- [Структура проекту](#-структура-проекту)
- [API документація](#-api-документація)
- [Деплой на Render](#-деплой-на-render)
- [Конфігурація](#-конфігурація)

## ✨ Можливості

### 🌐 Публічний сайт
- Калькулятор обміну валют в реальному часі
- Форма бронювання з вибором відділення та фіксацією курсу на 60 хвилин
- Карта з відділеннями та кнопками: дзвінок, чат, маршрут
- Актуальні курси валют
- Адаптивний дизайн (mobile-first)

### 👨‍💼 Адмін-панель (`/admin`)
- **Курси валют**: завантаження з Excel, перегляд базових/філіальних/крос-курсів
- **Бронювання**: перегляд всіх заявок з усіх відділень
- **Налаштування**:
  - Контактна інформація (телефони, email, соцмережі)
  - Управління відділеннями (адреси, телефони, години роботи)
  - Увімкнення/вимкнення валют
  - FAQ
  - Послуги

### 👷 Панель оператора (`/operator`)
- Перегляд бронювань тільки свого відділення
- Підтвердження / завершення / скасування бронювань
- Завантаження актуальних курсів для свого відділення
- Автооновлення кожні 15 секунд
- Сповіщення про нові бронювання

## 🛠 Технології

### Frontend
- React 18 + Vite
- Tailwind CSS
- React Router
- Axios
- Lucide Icons
- XLSX (для Excel)

### Backend
- FastAPI
- Pydantic
- Pandas + OpenPyXL
- Python 3.11+

## 🚀 Швидкий старт

### Docker (рекомендовано)

```bash
# Клонування
git clone https://github.com/your-repo/svit-valut.git
cd svit-valut

# Запуск
docker-compose up -d

# Відкрити
# Frontend: http://localhost:5173
# Backend:  http://localhost:8000
# API Docs: http://localhost:8000/docs
```

### Локальний запуск

```bash
# Backend
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000

# Frontend (в іншому терміналі)
cd frontend
npm install
npm run dev
```

### Скриптом

```bash
chmod +x start.sh
./start.sh
```

## 🔐 Облікові записи

| Роль | Логін | Пароль | Відділення |
|------|-------|--------|------------|
| Адміністратор | `admin` | `admin123` | Всі |
| Оператор 1 | `operator1` | `op1pass` | вул. Старовокзальна, 23 |
| Оператор 2 | `operator2` | `op2pass` | вул. В. Васильківська, 110 |
| Оператор 3 | `operator3` | `op3pass` | вул. В. Васильківська, 130 |
| Оператор 4 | `operator4` | `op4pass` | вул. Р. Окіпної, 2 |
| Оператор 5 | `operator5` | `op5pass` | вул. Саксаганського, 69 |

## 📁 Структура проекту

```
svit-valut/
├── backend/
│   ├── main.py              # FastAPI додаток
│   ├── requirements.txt     # Python залежності
│   └── Dockerfile
├── frontend/
│   ├── src/
│   │   ├── components/      # React компоненти
│   │   │   ├── Header.jsx
│   │   │   ├── HeroSection.jsx
│   │   │   ├── BranchesSection.jsx
│   │   │   ├── RatesSection.jsx
│   │   │   ├── FeaturesSection.jsx
│   │   │   ├── FAQSection.jsx
│   │   │   ├── ServicesSection.jsx
│   │   │   └── Footer.jsx
│   │   ├── pages/           # Сторінки
│   │   │   ├── AdminDashboard.jsx
│   │   │   ├── OperatorDashboard.jsx
│   │   │   ├── SettingsPage.jsx
│   │   │   ├── LoginPage.jsx
│   │   │   ├── RatesPage.jsx
│   │   │   └── ServicePage.jsx
│   │   ├── services/
│   │   │   └── api.js       # API сервіс
│   │   └── App.jsx
│   ├── public/
│   │   ├── sitemap.xml
│   │   └── robots.txt
│   ├── package.json
│   ├── vite.config.js
│   └── Dockerfile
├── docker-compose.yml
├── render.yaml              # Конфіг для Render
├── start.sh                 # Скрипт запуску
├── sample_rates.xlsx        # Приклад файлу курсів
└── README.md
```

## 📚 API документація

Swagger UI доступний за адресою: `http://localhost:8000/docs`

### Основні ендпоінти

| Метод | Ендпоінт | Опис |
|-------|----------|------|
| GET | `/api/currencies` | Список валют |
| GET | `/api/rates` | Поточні курси |
| GET | `/api/branches` | Список відділень |
| POST | `/api/reservations` | Створити бронювання |
| GET | `/api/settings` | Налаштування сайту |

### Адмін ендпоінти (потребують авторизації)

| Метод | Ендпоінт | Опис |
|-------|----------|------|
| POST | `/api/admin/rates/upload` | Завантажити курси з Excel |
| GET | `/api/admin/reservations` | Всі бронювання |
| PUT | `/api/admin/settings` | Оновити налаштування |
| PUT | `/api/admin/branches/{id}` | Оновити відділення |
| PUT | `/api/admin/currencies/{code}` | Увімкнути/вимкнути валюту |

### Оператор ендпоінти

| Метод | Ендпоінт | Опис |
|-------|----------|------|
| GET | `/api/operator/reservations` | Бронювання філії |
| POST | `/api/operator/reservations/{id}/confirm` | Підтвердити |
| POST | `/api/operator/reservations/{id}/complete` | Завершити |
| GET | `/api/operator/rates/download` | Завантажити курси |

## 🌍 Деплой на Render

### Автоматичний деплой

1. Завантажте репозиторій на GitHub
2. Зайдіть на [render.com](https://render.com)
3. Створіть новий **Blueprint** з вашого репозиторію
4. Render автоматично використає `render.yaml`

### Ручний деплой

**Backend:**
1. Новий Web Service → Python
2. Build: `pip install -r requirements.txt`
3. Start: `uvicorn main:app --host 0.0.0.0 --port $PORT`
4. Root: `backend`

**Frontend:**
1. Новий Static Site
2. Build: `npm install && npm run build`
3. Publish: `dist`
4. Root: `frontend`
5. Env: `VITE_API_URL=https://your-backend.onrender.com`

## ⚙️ Конфігурація

### Змінні середовища

**Frontend:**
```env
VITE_API_URL=http://localhost:8000
```

**Backend:**
```env
TZ=Europe/Kyiv
```

### Формат Excel для завантаження курсів

**Аркуш "Курси":**
| Код валюти | Назва | Купівля | Продаж |
|------------|-------|---------|--------|
| USD | Долар США | 42.10 | 42.15 |
| EUR | Євро | 49.30 | 49.35 |

**Аркуш "Відділення" (опціонально):**
| Відділення | Код валюти | Купівля | Продаж |
|------------|------------|---------|--------|
| 1 | USD | 42.05 | 42.20 |

**Аркуш "Крос-курси" (опціонально):**
| Пара | Купівля | Продаж |
|------|---------|--------|
| EUR/USD | 1.170 | 1.172 |

## 📱 Маршрути

| Шлях | Опис |
|------|------|
| `/` | Головна сторінка |
| `/rates` | Всі курси валют |
| `/services/:slug` | Сторінка послуги |
| `/login` | Авторизація |
| `/admin` | Адмін-панель |
| `/operator` | Панель оператора |

## 🔧 Розробка

```bash
# Запуск в режимі розробки
cd frontend && npm run dev

# Збірка для продакшену
cd frontend && npm run build

# Перевірка коду
cd frontend && npm run lint
```

## 📄 Ліцензія

MIT

---

Розроблено з ❤️ для Світ Валют
